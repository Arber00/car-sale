import logo from './logo.svg';
import "./App.css";
import {BrowserRouter, Routes, Route} from "react-router-dom";
import axios from "axios";
import React, {useState, useEffect} from "react";
import Main from "./views/Main";
import Create from "./views/Create";
import Show from "./views/Show";
import Edit from "./views/Edit";

function App() {

  return (
    <BrowserRouter>  
      <div className="App">
      <h1>Cars</h1>
        <Routes>
          <Route path="/" element={<Main/>}/>
          <Route path="/new" element={<Create/>}/>
          <Route path="/show/:id/" element={<Show/>}/>
          <Route path="/edit/:id/" element={<Edit/>}/>
        </Routes>
      </div>
    </BrowserRouter>
  );
}

export default App;
