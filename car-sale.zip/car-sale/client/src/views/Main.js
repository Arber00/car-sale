import React, {useState, useEffect} from "react";
import {Link} from "react-router-dom";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "./Main.css";


const Main =()=>{

    //manage state to display and remove information
    const [cars, setCars] = useState([]);
    const navigate = useNavigate();
    //get all cars in order to display them 
    useEffect(()=>{
        axios.get("http://localhost:8000/cars/getAll")
        .then(res=>{
            console.log(res);
            console.log(res.data);
            setCars(res.data.results);})
        .catch(err=>console.log(err))
    }, []);

    //delete car's with a specific id
    const deleteHandler =(carId)=>{
        // console.log(carId)
        axios.delete(`http://localhost:8000/cars/${carId}/delete`)
            .then(res=>{
                console.log(res);
                setCars(cars.filter(car => car._id !== carId));
            })
        

    }

    return(
        <div>
            <h1> <Link to={"/new"} className="Btn-black">Add Car</Link> </h1>
        
            {
                cars.map((car, index)=>{
                    return (
                        <div className="column-style" key={index}>
                            <div>
                                <img className="image-style" src={car.Link} alt="image"></img>
                                <h2>{ car.CarName }</h2>
                            </div>

                            <button className="Btn" onClick={()=>navigate(`/show/${car._id}`)}>SHOW</button>
                            <button className="Btn" onClick={()=>navigate(`/edit/${car._id}`)}>EDIT</button>
                            <button className="Btn" onClick={()=>deleteHandler(car._id)}>DELETE</button>
                                
                        </div>
                    )
                })
            }
            
        </div>
    );
}

export default Main;