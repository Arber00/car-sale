import Form from "../components/Form";
import React, {useState, useEffect} from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";

const Edit = () =>{

    const operation = "Edit this Car:";
    const [serverError, setServerError] = useState({});
    const [clientError, setClientError] = useState("");
    const {id} = useParams();
    const navigate = useNavigate();
    const [updateForm, setUpdateForm] = useState({
        CarName: "",
        Link: "",
        Description: "",
    });

    const onChangeHandler=(e)=>{
        setUpdateForm({
            ...updateForm,
            [e.target.name]: e.target.value,
            [e.target.name]: e.target.value,
            [e.target.name]: e.target.value,
        })
        // if (e.target.value.length < 3){
        //     setClientError("Car's name can't be less than 3 characters!");
        // }
        // else setClientError("");
    }
    useEffect(() => {
        axios.get("http://localhost:8000/cars/" + id)
            .then(res =>
                {console.log(res.data.results);
                    setUpdateForm({
                        CarName: res.data.results.CarName,
                        Link: res.data.results.Link,
                        Description: res.data.results.Description,
                    })})
            .catch(err => console.log(err))
    }, []);
    console.log(updateForm.CarName);

    const onSubmitHandler=(e)=>{
        e.preventDefault();
        axios.put(`http://localhost:8000/cars/${id}/update`, updateForm)
            .then(res=>console.log(res))
            .catch(err=>{
                console.log(err.response.data);
                setServerError(err.response.data.err.errors);
            });
        if (clientError===""){
            navigate("/")
        }
        else console.log(clientError);
    }

    return(
        <Form operation={operation} 
            onSubmitHandler={onSubmitHandler} 
            onChangeHandler={onChangeHandler} 
            value={
                {
                    CarName: updateForm.CarName,
                    Link: updateForm.Link,
                    Description: updateForm.Description,
                }
            } 
            clientError={clientError}
            serverError={serverError}/>
    );
}

export default Edit;