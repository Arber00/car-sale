import React, {useState, useEffect} from "react";
import {Link} from "react-router-dom";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useParams } from "react-router-dom";


const Main =()=>{

    //manage state to display and remove information
    const [car, setCars] = useState([]);
    const navigate = useNavigate();
    const {id} = useParams();
    //get all cars in order to display them 
    useEffect(()=>{
    axios.get("http://localhost:8000/cars/" + id)
        .then(res=>{
            setCars(res.data.results);})
        .catch(err=>console.log(err))
    }, []);

    return(
        <div>
            <h1>Show {car.CarName} </h1>
        
                <div>
                    <div>
                        <img className="image-style-show" src={car.Link} alt="image"></img>
                        <p> { car.Description }</p>
                    </div>
                        
                </div>
        </div>
    );
}

export default Main;