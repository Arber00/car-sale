import "./Form.css";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
const Form = (props) =>{

    const navigate = useNavigate();
    return(
    
        <div>
            <form onSubmit={props.onSubmitHandler}>
                <h3><Link to={"/"}>Home</Link></h3>
                <h4>{props.operation}</h4>
                <div className="Input-Div">
                    <p>Name:</p>
                    <input id="input" name="CarName" type="text" onChange={props.onChangeHandler} value={props.value?.CarName}/>
                        {
                            props.clientError ?
                                <p style={{color: "red"}}>{props.clientError}</p> :
                                ''
                        }
                        <p>Image Link:</p>
                        <input id="input" name="Link" type="text" onChange={props.onChangeHandler} value={props.value?.Link}/>
                            {
                                props.clientError ?
                                    <p style={{color: "red"}}>{props.clientError}</p> :
                                    ''
                            }

                        <p>Description:</p>
                        <textarea id="input" name="Description" onChange={props.onChangeHandler} value={props.value?.Description}/>
                            {
                                props.clientError ?
                                    <p style={{color: "red"}}>{props.clientError}</p> :
                                    ''
                            }
                    <div>
                </div>
            
                <div>
                    <button className="Btn-Form" onClick={()=>navigate("/")}>CANCEL</button>
                    <input className="Btn-Form" type="submit" value="SUBMIT"/>
                </div>
                </div>
            </form>
        </div>
    );
}

export default Form;