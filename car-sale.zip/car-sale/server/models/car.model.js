const mongoose = require("mongoose");

const CarSchema = mongoose.Schema({
    //let's add some mongoose schema validations based on the mongoose doc. I will add also the timestamps.
    CarName: {
        type: String,
        required: [true, "Title is mandatory!"],
        minLength: [3, "Car's name can't be less three characters!"]
    },
    Link: {
        type: String,
        required: [true],
    },
    Description: {
        type: String,
        required: [true],
    }
}, {timestamps: true});

const Car = mongoose.model("Car", CarSchema);
    module.exports = Car;