const CarController = require("../controllers/car.controller");

//test routes
module.exports = app =>{
    app.get("/check/index", CarController.index);
    app.get("/cars/getAll", CarController.getAllCars);
    app.post("/cars/new", CarController.createCar);
    app.get("/cars/:id", CarController.getOneCar);
    app.delete("/cars/:id/delete", CarController.deleteCar);
    app.put("/cars/:id/update", CarController.updateCar);
}

