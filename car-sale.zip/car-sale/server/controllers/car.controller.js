const Car = require("../models/car.model");

//test function to check routes
module.exports.index = (req, res) =>{
    res.json({message: "Hello Dojo!"});
}

module.exports.getAllCars = (req, res) =>{
    Car.find({}).sort({carName: 1})
        .then((allCars)=>res.json({results: allCars}))
        .catch((err)=> res.status(400).json({message: "Couldn't get all Cars!", err}));
}

module.exports.getOneCar = (req, res) =>{
    Car.findOne({_id: req.params.id})
        .then((oneCar)=>res.json({results: oneCar}))
        .catch((err)=> res.status(400).json({message: "Couldn't get the Author!", err}));
}

module.exports.deleteCar = (req, res) =>{
    Car.deleteOne({_id: req.params.id})
        .then(deletedCar=>res.json({results: deletedCar}))
        .catch((err)=>res.status(400).json({message: "Couldn't delete the Car!", err}));
}

module.exports.updateCar = (req, res) =>{
    Car.findOneAndUpdate({_id: req.params.id}, req.body, {runValidators: true})
        .then(updatedAuthor => res.json({results:updatedAuthor}))
        .catch(err =>res.status(400).json({message: "Couldn't update the Car!", err}));
}

module.exports.createCar = (req,res) => {
    Car.create(req.body)
    .then(newAuthor =>res.json({results: newAuthor}))
    .catch(err=>res.status(400).json({message: "Couldn't create the Car!", err}));
}